﻿namespace HotelBookingApp
{
    partial class ManageRoomsPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listViewBkngs = new System.Windows.Forms.ListView();
            this.Room_ID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Room = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Floor = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Type = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Window_view = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.WorkingDesk = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SittingArea = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.AccessibleRoom = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.AddRoomButton = new System.Windows.Forms.Button();
            this.EditSelectedButton = new System.Windows.Forms.Button();
            this.DeleteRoomButton = new System.Windows.Forms.Button();
            this.ManageRoomsMainLbl = new System.Windows.Forms.Label();
            this.AvailabilityComboBox = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // listViewBkngs
            // 
            this.listViewBkngs.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Room_ID,
            this.Room,
            this.Floor,
            this.Type,
            this.Window_view,
            this.WorkingDesk,
            this.SittingArea,
            this.AccessibleRoom});
            this.listViewBkngs.HideSelection = false;
            this.listViewBkngs.Location = new System.Drawing.Point(11, 88);
            this.listViewBkngs.Margin = new System.Windows.Forms.Padding(2);
            this.listViewBkngs.Name = "listViewBkngs";
            this.listViewBkngs.Size = new System.Drawing.Size(650, 305);
            this.listViewBkngs.TabIndex = 93;
            this.listViewBkngs.UseCompatibleStateImageBehavior = false;
            this.listViewBkngs.View = System.Windows.Forms.View.Details;
            this.listViewBkngs.SelectedIndexChanged += new System.EventHandler(this.listViewBkngs_SelectedIndexChanged);
            // 
            // Room_ID
            // 
            this.Room_ID.Text = "Room ID";
            // 
            // Room
            // 
            this.Room.Text = "Room #";
            // 
            // Floor
            // 
            this.Floor.Text = "Floor #";
            // 
            // Type
            // 
            this.Type.Text = "Type";
            this.Type.Width = 85;
            // 
            // Window_view
            // 
            this.Window_view.Text = "Window View";
            this.Window_view.Width = 100;
            // 
            // WorkingDesk
            // 
            this.WorkingDesk.Text = "Working Desk";
            this.WorkingDesk.Width = 90;
            // 
            // SittingArea
            // 
            this.SittingArea.Text = "Sitting Area";
            this.SittingArea.Width = 90;
            // 
            // AccessibleRoom
            // 
            this.AccessibleRoom.Text = "Accessible Room";
            this.AccessibleRoom.Width = 100;
            // 
            // AddRoomButton
            // 
            this.AddRoomButton.Location = new System.Drawing.Point(12, 398);
            this.AddRoomButton.Name = "AddRoomButton";
            this.AddRoomButton.Size = new System.Drawing.Size(120, 37);
            this.AddRoomButton.TabIndex = 100;
            this.AddRoomButton.Text = "Add Room";
            this.AddRoomButton.Click += new System.EventHandler(this.AddRoomButton_Click);
            // 
            // EditSelectedButton
            // 
            this.EditSelectedButton.ForeColor = System.Drawing.SystemColors.ControlText;
            this.EditSelectedButton.Location = new System.Drawing.Point(150, 398);
            this.EditSelectedButton.Name = "EditSelectedButton";
            this.EditSelectedButton.Size = new System.Drawing.Size(133, 37);
            this.EditSelectedButton.TabIndex = 97;
            this.EditSelectedButton.Text = "Edit Selected";
            this.EditSelectedButton.UseVisualStyleBackColor = true;
            // 
            // DeleteRoomButton
            // 
            this.DeleteRoomButton.BackColor = System.Drawing.Color.Salmon;
            this.DeleteRoomButton.Location = new System.Drawing.Point(528, 398);
            this.DeleteRoomButton.Name = "DeleteRoomButton";
            this.DeleteRoomButton.Size = new System.Drawing.Size(133, 37);
            this.DeleteRoomButton.TabIndex = 98;
            this.DeleteRoomButton.Text = "Delete Selected";
            this.DeleteRoomButton.UseVisualStyleBackColor = false;
            // 
            // ManageRoomsMainLbl
            // 
            this.ManageRoomsMainLbl.AutoSize = true;
            this.ManageRoomsMainLbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.ManageRoomsMainLbl.Location = new System.Drawing.Point(6, 9);
            this.ManageRoomsMainLbl.Name = "ManageRoomsMainLbl";
            this.ManageRoomsMainLbl.Size = new System.Drawing.Size(187, 25);
            this.ManageRoomsMainLbl.TabIndex = 99;
            this.ManageRoomsMainLbl.Text = "Room management ";
            // 
            // AvailabilityComboBox
            // 
            this.AvailabilityComboBox.FormattingEnabled = true;
            this.AvailabilityComboBox.Items.AddRange(new object[] {
            "0 - Available",
            "1 - Occupied"});
            this.AvailabilityComboBox.Location = new System.Drawing.Point(11, 53);
            this.AvailabilityComboBox.Name = "AvailabilityComboBox";
            this.AvailabilityComboBox.Size = new System.Drawing.Size(121, 21);
            this.AvailabilityComboBox.TabIndex = 101;
            // 
            // ManageRoomsPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(922, 447);
            this.Controls.Add(this.AvailabilityComboBox);
            this.Controls.Add(this.ManageRoomsMainLbl);
            this.Controls.Add(this.DeleteRoomButton);
            this.Controls.Add(this.EditSelectedButton);
            this.Controls.Add(this.AddRoomButton);
            this.Controls.Add(this.listViewBkngs);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ManageRoomsPanel";
            this.Text = "ManageRoomsPanel";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView listViewBkngs;
        private System.Windows.Forms.ColumnHeader Room;
        private System.Windows.Forms.ColumnHeader Type;
        private System.Windows.Forms.ColumnHeader Window_view;
        private System.Windows.Forms.ColumnHeader WorkingDesk;
        private System.Windows.Forms.ColumnHeader SittingArea;
        private System.Windows.Forms.ColumnHeader AccessibleRoom;
        private System.Windows.Forms.Button AddRoomButton;
        private System.Windows.Forms.Button EditSelectedButton;
        private System.Windows.Forms.ColumnHeader Floor;
        private System.Windows.Forms.Button DeleteRoomButton;
        private System.Windows.Forms.Label ManageRoomsMainLbl;
        private System.Windows.Forms.ColumnHeader Room_ID;
        public System.Windows.Forms.ComboBox AvailabilityComboBox;
    }
}