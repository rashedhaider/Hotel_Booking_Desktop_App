﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelBookingApp
{
    public partial class NewBookingPanel : Form
    {
        CheckIn CK = new CheckIn();
        CustomerDetails CD = new CustomerDetails();
        AdditionalRoomsForm ADF = new AdditionalRoomsForm();            
        AdditionalServicesForm ASF = new AdditionalServicesForm();
        Payment P = new Payment();
        public NewBookingPanel()
        {
            InitializeComponent();

        }

        private void button8_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void checkInBtn_Click(object sender, EventArgs e)
        {
            OpenChildform_NBP(CK, sender);
            
        }

        private void customerBtn_Click(object sender, EventArgs e)
        {
            OpenChildform_NBP(CD, sender);
        }

        private void AdditionalRoomsBtn_Click(object sender, EventArgs e)
        {
            OpenChildform_NBP(ADF, sender);
        }

        private void AdditionalServBtn_Click(object sender, EventArgs e)
        {
            OpenChildform_NBP(ASF, sender);
        }

        private void PaymentBtn_Click(object sender, EventArgs e)
        {
            OpenChildform_NBP(P, sender);
        }

        private void FormsContainer_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
