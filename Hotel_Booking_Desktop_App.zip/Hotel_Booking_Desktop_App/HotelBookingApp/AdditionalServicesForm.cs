﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelBookingApp
{
    public partial class AdditionalServicesForm : Form
    {
        public AdditionalServicesForm()
        {
            InitializeComponent();

            //Creates a dictionary with items descriptions
            Dictionary<int, string> Descriptions = new Dictionary<int, string>();
            Descriptions.Add(0, "Room service staff will come collect items at 10am unless 'Do not disturb' sign is put at the door. Items to be returned at 5pm the same day.");
            Descriptions.Add(1, "Room service staff will come collect items at 10am unless 'Do not disturb' sign is put at the door. Items to be returned at 5pm the same day. If fail to collect items, please inform reception to rearrange collection (customer to be charged for the service regardless).");
            Descriptions.Add(2, "Room service staff will come collect items at 10am of the agreed starting day unless 'Do not disturb' sign is put at the door. Items to be returned at 5pm the same day. If fail to collect items, please inform reception to rearrange collection (customer to be charged for the service regardless).");
            Descriptions.Add(3, "Regular breakfast offered, check hotel menu.");
            Descriptions.Add(4, "Regular breakfast plus vegan/vegetarian options, check hotel menu.");
            Descriptions.Add(5, "Regular lunch offered, check hotel menu.");
            Descriptions.Add(6, "Regular lunch plus vegan/vegetarian options, check hotel menu.");
            Descriptions.Add(7, "Regular dinner offered, check hotel menu.");
            Descriptions.Add(8, "Hotel staff will assist moving customer luggage during check in and check out.");
            

        }

        public void checkedListAddServ_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            //this should add the service charge amount into the grand total.
           


        }

        public void checkedListAddServ_SelectedIndexChanged(object sender, EventArgs e)
        {
            string itemChecked = checkedListAddServ.SelectedIndex.ToString();
            //converts the checked item in the list into a string that can be used then to display the description as per database entry
            foreach (string item in checkedListAddServ.CheckedItems) 
            {
                if (item == itemChecked)
                {
                    
                }
            
            }   
            
            
        }
    }
}
