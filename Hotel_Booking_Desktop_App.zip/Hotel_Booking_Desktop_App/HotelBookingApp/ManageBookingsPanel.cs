﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelBookingApp
{
    public partial class ManageBookingsPanel : Form
    {
        public ManageBookingsPanel()
        {
            InitializeComponent();
        }

        private void AddServBtn_Click(object sender, EventArgs e)
        {
            //open new additional services form in a new window that allows user to add more services to selected booking.
            AdditionalServicesForm addServices = new AdditionalServicesForm();
            addServices.Size = new Size(413, 450);
            addServices.FormBorderStyle = FormBorderStyle.FixedSingle;
            addServices.Show();
            int addedServices;
            
        }

        private void SearchBtn_Click(object sender, EventArgs e)
        {
            //search the selected room and display details on the list below it.
            string roomToSearch = BkngsList.SelectedItem.ToString();
            
            //sends query to the database using the selected roomID
        }
    }
}
