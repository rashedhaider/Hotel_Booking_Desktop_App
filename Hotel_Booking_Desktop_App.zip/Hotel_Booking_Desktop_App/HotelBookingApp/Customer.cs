﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HotelBookingApp
{
    public class Customer
    {

        public string CustomerID { get; set; }
        public string FullName { get; set; }
        public string Gender { get; set; }
        public DateTime DOB { get; set; }
        public string Address { get; set; }
        public string PhoneNumber { get; set; } 

            
        public void customer(string customerID,string fullName, string gender,DateTime dob, string address, string phoneNumber)
        {
            CustomerID = customerID;
            FullName = fullName;
            Gender = gender;
            DOB = dob;
            Address = address;
            PhoneNumber = phoneNumber;
        }
    }
}
