﻿namespace HotelBookingApp
{
    partial class ManageBookingsPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listViewBkngs = new System.Windows.Forms.ListView();
            this.Room = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Type = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Window_view = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.WorkingDesk = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SittingArea = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.AccessibleRoom = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Customer = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Guests = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.BkngsList = new System.Windows.Forms.ComboBox();
            this.AddServBtn = new System.Windows.Forms.Button();
            this.ModifyBkngBtn = new System.Windows.Forms.Button();
            this.RoomLabel = new System.Windows.Forms.Label();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SearchBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // listViewBkngs
            // 
            this.listViewBkngs.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Room,
            this.Type,
            this.Window_view,
            this.WorkingDesk,
            this.SittingArea,
            this.AccessibleRoom,
            this.Customer,
            this.Guests,
            this.columnHeader1});
            this.listViewBkngs.HideSelection = false;
            this.listViewBkngs.Location = new System.Drawing.Point(11, 87);
            this.listViewBkngs.Margin = new System.Windows.Forms.Padding(2);
            this.listViewBkngs.Name = "listViewBkngs";
            this.listViewBkngs.Size = new System.Drawing.Size(729, 174);
            this.listViewBkngs.TabIndex = 92;
            this.listViewBkngs.UseCompatibleStateImageBehavior = false;
            this.listViewBkngs.View = System.Windows.Forms.View.Details;
            // 
            // Room
            // 
            this.Room.DisplayIndex = 2;
            this.Room.Text = "Room";
            // 
            // Type
            // 
            this.Type.DisplayIndex = 3;
            this.Type.Text = "Type";
            this.Type.Width = 85;
            // 
            // Window_view
            // 
            this.Window_view.DisplayIndex = 4;
            this.Window_view.Text = "Window View";
            this.Window_view.Width = 100;
            // 
            // WorkingDesk
            // 
            this.WorkingDesk.DisplayIndex = 5;
            this.WorkingDesk.Text = "Working Desk";
            this.WorkingDesk.Width = 90;
            // 
            // SittingArea
            // 
            this.SittingArea.DisplayIndex = 6;
            this.SittingArea.Text = "Sitting Area";
            this.SittingArea.Width = 90;
            // 
            // AccessibleRoom
            // 
            this.AccessibleRoom.DisplayIndex = 7;
            this.AccessibleRoom.Text = "Accessible Room";
            this.AccessibleRoom.Width = 100;
            // 
            // Customer
            // 
            this.Customer.DisplayIndex = 1;
            this.Customer.Text = "Customer";
            // 
            // Guests
            // 
            this.Guests.DisplayIndex = 8;
            this.Guests.Text = "Guests";
            // 
            // BkngsList
            // 
            this.BkngsList.FormattingEnabled = true;
            this.BkngsList.Items.AddRange(new object[] {
            "Room 101",
            "Room 102",
            "Room 103",
            "Room 105",
            "Room 201",
            "Room 202",
            "Room 203",
            "Room 204",
            "Room 205",
            "Room 301",
            "Room 302",
            "Room 303",
            "Room 304",
            "Room 305",
            "Room 401",
            "Room 402",
            "Room 403"});
            this.BkngsList.Location = new System.Drawing.Point(11, 44);
            this.BkngsList.Name = "BkngsList";
            this.BkngsList.Size = new System.Drawing.Size(336, 21);
            this.BkngsList.TabIndex = 94;
            // 
            // AddServBtn
            // 
            this.AddServBtn.ForeColor = System.Drawing.SystemColors.ControlText;
            this.AddServBtn.Location = new System.Drawing.Point(11, 281);
            this.AddServBtn.Name = "AddServBtn";
            this.AddServBtn.Size = new System.Drawing.Size(133, 37);
            this.AddServBtn.TabIndex = 95;
            this.AddServBtn.Text = "Add services";
            this.AddServBtn.UseVisualStyleBackColor = true;
            this.AddServBtn.Click += new System.EventHandler(this.AddServBtn_Click);
            // 
            // ModifyBkngBtn
            // 
            this.ModifyBkngBtn.ForeColor = System.Drawing.SystemColors.ControlText;
            this.ModifyBkngBtn.Location = new System.Drawing.Point(150, 281);
            this.ModifyBkngBtn.Name = "ModifyBkngBtn";
            this.ModifyBkngBtn.Size = new System.Drawing.Size(133, 37);
            this.ModifyBkngBtn.TabIndex = 96;
            this.ModifyBkngBtn.Text = "Modify booking";
            this.ModifyBkngBtn.UseVisualStyleBackColor = true;
            // 
            // RoomLabel
            // 
            this.RoomLabel.AutoSize = true;
            this.RoomLabel.Location = new System.Drawing.Point(12, 28);
            this.RoomLabel.Name = "RoomLabel";
            this.RoomLabel.Size = new System.Drawing.Size(84, 13);
            this.RoomLabel.TabIndex = 97;
            this.RoomLabel.Text = "Select the room:";
            // 
            // columnHeader1
            // 
            this.columnHeader1.DisplayIndex = 0;
            this.columnHeader1.Text = "Booking ID";
            this.columnHeader1.Width = 79;
            // 
            // SearchBtn
            // 
            this.SearchBtn.Location = new System.Drawing.Point(365, 44);
            this.SearchBtn.Name = "SearchBtn";
            this.SearchBtn.Size = new System.Drawing.Size(75, 21);
            this.SearchBtn.TabIndex = 98;
            this.SearchBtn.Text = "Search";
            this.SearchBtn.UseVisualStyleBackColor = true;
            this.SearchBtn.Click += new System.EventHandler(this.SearchBtn_Click);
            // 
            // ManageBookingsPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(922, 447);
            this.Controls.Add(this.SearchBtn);
            this.Controls.Add(this.RoomLabel);
            this.Controls.Add(this.ModifyBkngBtn);
            this.Controls.Add(this.AddServBtn);
            this.Controls.Add(this.BkngsList);
            this.Controls.Add(this.listViewBkngs);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "ManageBookingsPanel";
            this.Text = "ManageBookingsForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListView listViewBkngs;
        private System.Windows.Forms.ColumnHeader Room;
        private System.Windows.Forms.ColumnHeader Type;
        private System.Windows.Forms.ColumnHeader Window_view;
        private System.Windows.Forms.ColumnHeader WorkingDesk;
        private System.Windows.Forms.ColumnHeader SittingArea;
        private System.Windows.Forms.ColumnHeader AccessibleRoom;
        private System.Windows.Forms.ComboBox BkngsList;
        private System.Windows.Forms.ColumnHeader Customer;
        private System.Windows.Forms.ColumnHeader Guests;
        private System.Windows.Forms.Button AddServBtn;
        private System.Windows.Forms.Button ModifyBkngBtn;
        private System.Windows.Forms.Label RoomLabel;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.Button SearchBtn;
    }
}