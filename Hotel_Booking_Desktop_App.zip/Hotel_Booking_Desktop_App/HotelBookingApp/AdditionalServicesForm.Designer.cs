﻿namespace HotelBookingApp
{
    partial class AdditionalServicesForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.checkedListAddServ = new System.Windows.Forms.CheckedListBox();
            this.ConfAddServBtn = new System.Windows.Forms.Button();
            this.AddServToAddlbl = new System.Windows.Forms.Label();
            this.ServiceDescLbl = new System.Windows.Forms.Label();
            this.ServSelectedLbl = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // checkedListAddServ
            // 
            this.checkedListAddServ.FormattingEnabled = true;
            this.checkedListAddServ.Items.AddRange(new object[] {
            "Laundry - Every day",
            "Laundry - Every other day",
            "Laundry - Once a week",
            "Breakfast - Simple plan",
            "Breakfast - Premium(Includes vegetarian option)",
            "Lunch - Simple plan",
            "Lunch - Premium(Includes vegetarian option)",
            "Dinner - Simple plan",
            "Dinner - Premium(Includes vegetarian option)",
            "Luggage Assistance"});
            this.checkedListAddServ.Location = new System.Drawing.Point(12, 12);
            this.checkedListAddServ.Name = "checkedListAddServ";
            this.checkedListAddServ.Size = new System.Drawing.Size(385, 214);
            this.checkedListAddServ.TabIndex = 0;
            this.checkedListAddServ.ThreeDCheckBoxes = true;
            this.checkedListAddServ.ItemCheck += new System.Windows.Forms.ItemCheckEventHandler(this.checkedListAddServ_ItemCheck);
            this.checkedListAddServ.SelectedIndexChanged += new System.EventHandler(this.checkedListAddServ_SelectedIndexChanged);
            // 
            // ConfAddServBtn
            // 
            this.ConfAddServBtn.Location = new System.Drawing.Point(285, 399);
            this.ConfAddServBtn.Name = "ConfAddServBtn";
            this.ConfAddServBtn.Size = new System.Drawing.Size(112, 39);
            this.ConfAddServBtn.TabIndex = 1;
            this.ConfAddServBtn.Text = "Confirm services";
            this.ConfAddServBtn.UseVisualStyleBackColor = true;
            // 
            // AddServToAddlbl
            // 
            this.AddServToAddlbl.AutoSize = true;
            this.AddServToAddlbl.Location = new System.Drawing.Point(16, 399);
            this.AddServToAddlbl.Name = "AddServToAddlbl";
            this.AddServToAddlbl.Size = new System.Drawing.Size(67, 13);
            this.AddServToAddlbl.TabIndex = 4;
            this.AddServToAddlbl.Text = "Total to add:";
            // 
            // ServiceDescLbl
            // 
            this.ServiceDescLbl.AutoSize = true;
            this.ServiceDescLbl.Location = new System.Drawing.Point(13, 233);
            this.ServiceDescLbl.Name = "ServiceDescLbl";
            this.ServiceDescLbl.Size = new System.Drawing.Size(102, 13);
            this.ServiceDescLbl.TabIndex = 2;
            this.ServiceDescLbl.Text = "Service Description:";
            // 
            // ServSelectedLbl
            // 
            this.ServSelectedLbl.AutoSize = true;
            this.ServSelectedLbl.Location = new System.Drawing.Point(12, 250);
            this.ServSelectedLbl.Name = "ServSelectedLbl";
            this.ServSelectedLbl.Size = new System.Drawing.Size(92, 13);
            this.ServSelectedLbl.TabIndex = 3;
            this.ServSelectedLbl.Text = "*Description here*";
            // 
            // AdditionalServicesForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.AddServToAddlbl);
            this.Controls.Add(this.ServSelectedLbl);
            this.Controls.Add(this.ServiceDescLbl);
            this.Controls.Add(this.ConfAddServBtn);
            this.Controls.Add(this.checkedListAddServ);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AdditionalServicesForm";
            this.Text = "AdditionalServicesForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckedListBox checkedListAddServ;
        private System.Windows.Forms.Button ConfAddServBtn;
        private System.Windows.Forms.Label AddServToAddlbl;
        private System.Windows.Forms.Label ServiceDescLbl;
        private System.Windows.Forms.Label ServSelectedLbl;
    }
}