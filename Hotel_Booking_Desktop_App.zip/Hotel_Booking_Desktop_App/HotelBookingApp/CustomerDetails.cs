﻿using Org.BouncyCastle.Utilities;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelBookingApp
{
    public partial class CustomerDetails : Form
    {
        public CustomerDetails()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }

        

        private void CheckInBtn_Click(object sender, EventArgs e)
        {
            Customer customer = new Customer();
            customer.FullName = ForenameTextBox.Text.ToString() + " " + SurnameTextBox.Text.ToString();
            customer.Gender = GenderComboBox.Text.ToString();
            DOBDateTimePicker.CustomFormat = "DD MM YYYY";
            customer.DOB = DOBDateTimePicker.Value;
            customer.Address = Address1TextBox.Text.ToString() + " " + Address2TextBox.Text.ToString() + " " + Address3TextBox.Text.ToString() + "," + PostcodeTextBox.Text.ToString();
            customer.PhoneNumber = PhoneNumberTextBox.Text.ToString();
            
            SQLMethods sqlMethods = new SQLMethods();
            sqlMethods.AddCustomer(customer);
        }
    }
}
