
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelBookingApp
{
    /// <summary>
    /// Provides methods for database operations related to the Hotel Booking Application.
    /// </summary>
    public class SQLMethods
    {
        private bool Approval;

        // Connection string for SQL database
        private const string ConnectionString = @"Data Source=EDUARDOPC\SQLEXPRESS;Initial Catalog=HotelBookingAppDB;Integrated Security=True";
        private SqlConnection conn;
        private SqlCommand cmd;

        /// <summary>
        /// Initializes a new instance of the SQLMethods class.
        /// </summary>
        public SQLMethods()
        {
            conn = new SqlConnection(ConnectionString);
            cmd = new SqlCommand();
            cmd.Connection = conn;
        }

        // Add other methods with appropriate comments and refactoring
        // ...
    }
}
