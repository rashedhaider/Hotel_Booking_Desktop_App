
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MySql.Data.MySqlClient;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace HotelBookingApp
{
    /// <summary>
    /// Contains utility functions for various operations in the Hotel Booking Application.
    /// </summary>
    internal class Funcs
    {
        // Database connection for utility functions
        private static readonly SqlConnection conn = new SqlConnection(@"Data Source=ANAS99\SQLEXPRESS;Initial Catalog=HotelBookingAppDB;Integrated Security=True");

        /// <summary>
        /// Retrieves a specific ID from the database based on table and column name.
        /// </summary>
        /// <param name="TableName">Name of the database table.</param>
        /// <param name="ColumnName">Name of the column to retrieve the ID from.</param>
        /// <returns>Returns the retrieved ID as a string.</returns>
        public string RetrieveIDfromDatabase(string TableName, string ColumnName)
        {
            // Implementation of the method
            // ...

            return ID;
        }

        // Add other methods with appropriate comments and refactoring
        // ...
    }
}
