﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace HotelBookingApp
{
    public partial class AdminLogin: Form
    {

        public AdminLogin()
        {
            InitializeComponent();

        }

        private void AdminLogin_FormClosed(object sender, FormClosedEventArgs e)
        {
            Form FirstMenuFormOpened = Application.OpenForms.Cast<Form>().First();
            FirstMenuFormOpened.Enabled = true;
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            string userToValidate = UsernameTextBox.Text;
            string passwordToValidate = PasswordTextBox.Text;
            SQLMethods sqlMethods = new SQLMethods();
            bool loginAuthorized = sqlMethods.GetCredentials(userToValidate,passwordToValidate);
            
            if (loginAuthorized == true)
            {
                MainMenu mainMenu = new MainMenu();
                mainMenu.Show();
                this.Hide();      
            }
            else
            {
                MessageBox.Show("Credentials Not Correct");
                UsernameTextBox.Clear();
                PasswordTextBox.Clear();
                UsernameTextBox.Focus();
            }
        }

        private void CancelButton_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void UsernameTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                e.Handled = true;
                SendKeys.Send("{TAB}");
            }
        }

        private void PasswordTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                e.Handled = true;
                LoginButton_Click(sender, e);
            }
        }
    }
}
