﻿namespace HotelBookingApp
{
    partial class AdditionalRoomsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button8 = new System.Windows.Forms.Button();
            this.listViewRoomTypes = new System.Windows.Forms.ListView();
            this.Room = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Type = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.Window_view = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.WorkingDesk = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SittingArea = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.AccessibleRoom = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SuspendLayout();
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(12, 342);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(149, 42);
            this.button8.TabIndex = 92;
            this.button8.Text = "Select rooms";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // listViewRoomTypes
            // 
            this.listViewRoomTypes.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.Room,
            this.Type,
            this.Window_view,
            this.WorkingDesk,
            this.SittingArea,
            this.AccessibleRoom});
            this.listViewRoomTypes.HideSelection = false;
            this.listViewRoomTypes.Location = new System.Drawing.Point(12, 10);
            this.listViewRoomTypes.Margin = new System.Windows.Forms.Padding(2);
            this.listViewRoomTypes.Name = "listViewRoomTypes";
            this.listViewRoomTypes.Size = new System.Drawing.Size(529, 327);
            this.listViewRoomTypes.TabIndex = 93;
            this.listViewRoomTypes.UseCompatibleStateImageBehavior = false;
            this.listViewRoomTypes.View = System.Windows.Forms.View.Details;
            // 
            // Room
            // 
            this.Room.Text = "Room";
            // 
            // Type
            // 
            this.Type.Text = "Type";
            this.Type.Width = 85;
            // 
            // Window_view
            // 
            this.Window_view.Text = "Window View";
            this.Window_view.Width = 100;
            // 
            // WorkingDesk
            // 
            this.WorkingDesk.Text = "Working Desk";
            this.WorkingDesk.Width = 90;
            // 
            // SittingArea
            // 
            this.SittingArea.Text = "Sitting Area";
            this.SittingArea.Width = 90;
            // 
            // AccessibleRoom
            // 
            this.AccessibleRoom.Text = "Accessible Room";
            this.AccessibleRoom.Width = 100;
            // 
            // AdditionalRoomsForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(708, 408);
            this.Controls.Add(this.listViewRoomTypes);
            this.Controls.Add(this.button8);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AdditionalRoomsForm";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.ListView listViewRoomTypes;
        private System.Windows.Forms.ColumnHeader Room;
        private System.Windows.Forms.ColumnHeader Type;
        private System.Windows.Forms.ColumnHeader Window_view;
        private System.Windows.Forms.ColumnHeader WorkingDesk;
        private System.Windows.Forms.ColumnHeader SittingArea;
        private System.Windows.Forms.ColumnHeader AccessibleRoom;
    }
}