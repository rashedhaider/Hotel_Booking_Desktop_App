﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelBookingApp
{
    public partial class ManageRoomsPanel : Form
    {
        public ManageRoomsPanel()
        {
            InitializeComponent();
            listViewBkngs.Items.Clear();
            SQLMethods sql = new SQLMethods();
            string availability = AvailabilityComboBox.Text;            
            sql.GetAvailableRooms(1, listViewBkngs);
                
        }

        
        private void AddServBtn_Click(object sender, EventArgs e)
        {

        }

        private void listViewBkngs_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void AddRoomButton_Click(object sender, EventArgs e)
        {
            AddRoomForm AddRoom = new AddRoomForm();
            AddRoom.Show();
        }
    }
}
