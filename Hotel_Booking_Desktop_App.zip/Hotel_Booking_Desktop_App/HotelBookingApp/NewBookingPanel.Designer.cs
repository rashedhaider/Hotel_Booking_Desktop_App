﻿using System.Windows.Forms;

namespace HotelBookingApp
{
    partial class NewBookingPanel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
       

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CheckInBtn = new System.Windows.Forms.Button();
            this.CustomerBtn = new System.Windows.Forms.Button();
            this.AdditionalRoomsBtn = new System.Windows.Forms.Button();
            this.PaymentBtn = new System.Windows.Forms.Button();
            this.AdditionalServBtn = new System.Windows.Forms.Button();
            this.CancelBookingBtn = new System.Windows.Forms.Button();
            this.FormsContainer = new System.Windows.Forms.Panel();
            this.SuspendLayout();
            // 
            // CheckInBtn
            // 
            this.CheckInBtn.Location = new System.Drawing.Point(413, 34);
            this.CheckInBtn.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.CheckInBtn.Name = "CheckInBtn";
            this.CheckInBtn.Size = new System.Drawing.Size(352, 120);
            this.CheckInBtn.TabIndex = 63;
            this.CheckInBtn.Text = "Check in";
            this.CheckInBtn.UseVisualStyleBackColor = true;
            this.CheckInBtn.Click += new System.EventHandler(this.checkInBtn_Click);
            // 
            // CustomerBtn
            // 
            this.CustomerBtn.BackColor = System.Drawing.Color.IndianRed;
            this.CustomerBtn.Location = new System.Drawing.Point(41, 34);
            this.CustomerBtn.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.CustomerBtn.Name = "CustomerBtn";
            this.CustomerBtn.Size = new System.Drawing.Size(352, 120);
            this.CustomerBtn.TabIndex = 60;
            this.CustomerBtn.Text = "Customer";
            this.CustomerBtn.UseVisualStyleBackColor = false;
            this.CustomerBtn.Click += new System.EventHandler(this.customerBtn_Click);
            // 
            // AdditionalRoomsBtn
            // 
            this.AdditionalRoomsBtn.Location = new System.Drawing.Point(785, 34);
            this.AdditionalRoomsBtn.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.AdditionalRoomsBtn.Name = "AdditionalRoomsBtn";
            this.AdditionalRoomsBtn.Size = new System.Drawing.Size(352, 120);
            this.AdditionalRoomsBtn.TabIndex = 66;
            this.AdditionalRoomsBtn.Text = "Additional Rooms";
            this.AdditionalRoomsBtn.UseVisualStyleBackColor = true;
            this.AdditionalRoomsBtn.Click += new System.EventHandler(this.AdditionalRoomsBtn_Click);
            // 
            // PaymentBtn
            // 
            this.PaymentBtn.Location = new System.Drawing.Point(1526, 34);
            this.PaymentBtn.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.PaymentBtn.Name = "PaymentBtn";
            this.PaymentBtn.Size = new System.Drawing.Size(352, 120);
            this.PaymentBtn.TabIndex = 65;
            this.PaymentBtn.Text = "Payment";
            this.PaymentBtn.UseVisualStyleBackColor = true;
            this.PaymentBtn.Click += new System.EventHandler(this.PaymentBtn_Click);
            // 
            // AdditionalServBtn
            // 
            this.AdditionalServBtn.Location = new System.Drawing.Point(1156, 34);
            this.AdditionalServBtn.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.AdditionalServBtn.Name = "AdditionalServBtn";
            this.AdditionalServBtn.Size = new System.Drawing.Size(352, 120);
            this.AdditionalServBtn.TabIndex = 64;
            this.AdditionalServBtn.Text = "Additional Services";
            this.AdditionalServBtn.UseVisualStyleBackColor = true;
            this.AdditionalServBtn.Click += new System.EventHandler(this.AdditionalServBtn_Click);
            // 
            // CancelBookingBtn
            // 
            this.CancelBookingBtn.BackColor = System.Drawing.Color.Salmon;
            this.CancelBookingBtn.Location = new System.Drawing.Point(2286, 34);
            this.CancelBookingBtn.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.CancelBookingBtn.Name = "CancelBookingBtn";
            this.CancelBookingBtn.Size = new System.Drawing.Size(551, 120);
            this.CancelBookingBtn.TabIndex = 68;
            this.CancelBookingBtn.Text = "Cancel booking";
            this.CancelBookingBtn.UseVisualStyleBackColor = false;
            // 
            // FormsContainer
            // 
            this.FormsContainer.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.FormsContainer.Location = new System.Drawing.Point(0, 168);
            this.FormsContainer.Margin = new System.Windows.Forms.Padding(6);
            this.FormsContainer.Name = "FormsContainer";
            this.FormsContainer.Size = new System.Drawing.Size(2863, 1318);
            this.FormsContainer.TabIndex = 69;
            this.FormsContainer.Paint += new System.Windows.Forms.PaintEventHandler(this.FormsContainer_Paint);
            // 
            // NewBookingPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(19F, 37F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2863, 1486);
            this.Controls.Add(this.CustomerBtn);
            this.Controls.Add(this.FormsContainer);
            this.Controls.Add(this.CancelBookingBtn);
            this.Controls.Add(this.AdditionalRoomsBtn);
            this.Controls.Add(this.PaymentBtn);
            this.Controls.Add(this.AdditionalServBtn);
            this.Controls.Add(this.CheckInBtn);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(10, 9, 10, 9);
            this.Name = "NewBookingPanel";
            this.Text = "Form3";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button CheckInBtn;
        private System.Windows.Forms.Button CustomerBtn;
        private System.Windows.Forms.Button AdditionalRoomsBtn;
        private System.Windows.Forms.Button PaymentBtn;
        private System.Windows.Forms.Button AdditionalServBtn;
        private System.Windows.Forms.Button CancelBookingBtn;
        public Panel FormsContainer;
        private Form activeForm;
        public void OpenChildform_NBP(Form childForm, object btnSender)
        {
           

            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            this.FormsContainer.Controls.Add(childForm);
            this.FormsContainer.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();

        }

        
    }
}