﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelBookingApp
{
    public partial class MainMenu : Form
    {
       
        public MainMenu()
        {
            InitializeComponent();
            
        }

        private void Form2_Load(object sender, EventArgs e)
        {
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (activeDetailsForm != null)
            {
                activeDetailsForm.Close();
            }
            ManageBookingsPanel ManageBookingsPanel = new ManageBookingsPanel();
            OpenChildform(ManageBookingsPanel, sender);
            
        }


        private void button3_Click(object sender, EventArgs e)
        {
            AdminLogin Login = new AdminLogin();
            Login.Show();
            
            ManageRoomsPanel ManageRoomsPanel = new ManageRoomsPanel();
            OpenChildform(ManageRoomsPanel, sender);
        }

        private void Reports_button_Click(object sender, EventArgs e)
        {
            AdminLogin Reports_Login = new AdminLogin();
            Reports_Login.Show();
            
        }

        private void NewBooking_Click(object sender, EventArgs e)
        {
            NewBookingPanel NewBookingPanel = new NewBookingPanel();
            OpenChildform(NewBookingPanel, sender);
            NewBookingPanel.OpenChildform_NBP(new CustomerDetails(), sender);
            DetailsPanel DetailsPanel = new DetailsPanel();
            OpenDetailsform(DetailsPanel, sender);

        }

        private void panelDesktopPane_Paint(object sender, PaintEventArgs e)
        {

        }

        private void newCustomerButton_Click(object sender, EventArgs e)
        {
            CustomerDetails CustomerDetailsPanel = new CustomerDetails();
            OpenChildform(CustomerDetailsPanel, sender);
        }
    }
}
