﻿
namespace HotelBookingApp
{
    partial class CustomerDetails
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CustomerDetails));
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.DOBDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.label9 = new System.Windows.Forms.Label();
            this.GenderComboBox = new System.Windows.Forms.ComboBox();
            this.ForenameTextBox = new System.Windows.Forms.TextBox();
            this.Address1TextBox = new System.Windows.Forms.TextBox();
            this.SurnameTextBox = new System.Windows.Forms.TextBox();
            this.Address2TextBox = new System.Windows.Forms.TextBox();
            this.Address3TextBox = new System.Windows.Forms.TextBox();
            this.PostcodeTextBox = new System.Windows.Forms.TextBox();
            this.CheckInBtn = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.PhoneNumberTextBox = new System.Windows.Forms.TextBox();
            this.NewCustomerPanel = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label22 = new System.Windows.Forms.Label();
            this.NewCustomerPanel.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(10, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 17);
            this.label1.TabIndex = 123;
            this.label1.Text = "Forename";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(10, 43);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 17);
            this.label2.TabIndex = 124;
            this.label2.Text = "Surname";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(10, 77);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 17);
            this.label4.TabIndex = 125;
            this.label4.Text = "Gender";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(361, 42);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 17);
            this.label6.TabIndex = 127;
            this.label6.Text = "Address line 2";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(361, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(90, 17);
            this.label5.TabIndex = 128;
            this.label5.Text = "Address line 1";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(361, 108);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(63, 17);
            this.label8.TabIndex = 129;
            this.label8.Text = "Postcode";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(361, 76);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(90, 17);
            this.label7.TabIndex = 130;
            this.label7.Text = "Address line 3";
            // 
            // DOBDateTimePicker
            // 
            this.DOBDateTimePicker.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DOBDateTimePicker.Location = new System.Drawing.Point(111, 108);
            this.DOBDateTimePicker.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.DOBDateTimePicker.MaxDate = new System.DateTime(2022, 7, 14, 0, 0, 0, 0);
            this.DOBDateTimePicker.MinDate = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.DOBDateTimePicker.Name = "DOBDateTimePicker";
            this.DOBDateTimePicker.Size = new System.Drawing.Size(224, 22);
            this.DOBDateTimePicker.TabIndex = 132;
            this.DOBDateTimePicker.Value = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(10, 112);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(46, 17);
            this.label9.TabIndex = 133;
            this.label9.Text = "D.O.B.";
            // 
            // GenderComboBox
            // 
            this.GenderComboBox.FormattingEnabled = true;
            this.GenderComboBox.Items.AddRange(new object[] {
            "Male",
            "Female"});
            this.GenderComboBox.Location = new System.Drawing.Point(111, 76);
            this.GenderComboBox.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.GenderComboBox.Name = "GenderComboBox";
            this.GenderComboBox.Size = new System.Drawing.Size(90, 21);
            this.GenderComboBox.TabIndex = 136;
            // 
            // ForenameTextBox
            // 
            this.ForenameTextBox.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForenameTextBox.Location = new System.Drawing.Point(111, 5);
            this.ForenameTextBox.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.ForenameTextBox.Multiline = true;
            this.ForenameTextBox.Name = "ForenameTextBox";
            this.ForenameTextBox.Size = new System.Drawing.Size(220, 21);
            this.ForenameTextBox.TabIndex = 137;
            // 
            // Address1TextBox
            // 
            this.Address1TextBox.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Address1TextBox.Location = new System.Drawing.Point(461, 4);
            this.Address1TextBox.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.Address1TextBox.Multiline = true;
            this.Address1TextBox.Name = "Address1TextBox";
            this.Address1TextBox.Size = new System.Drawing.Size(369, 21);
            this.Address1TextBox.TabIndex = 138;
            // 
            // SurnameTextBox
            // 
            this.SurnameTextBox.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SurnameTextBox.Location = new System.Drawing.Point(111, 38);
            this.SurnameTextBox.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.SurnameTextBox.Multiline = true;
            this.SurnameTextBox.Name = "SurnameTextBox";
            this.SurnameTextBox.Size = new System.Drawing.Size(220, 21);
            this.SurnameTextBox.TabIndex = 139;
            // 
            // Address2TextBox
            // 
            this.Address2TextBox.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Address2TextBox.Location = new System.Drawing.Point(461, 37);
            this.Address2TextBox.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.Address2TextBox.Multiline = true;
            this.Address2TextBox.Name = "Address2TextBox";
            this.Address2TextBox.Size = new System.Drawing.Size(369, 21);
            this.Address2TextBox.TabIndex = 140;
            // 
            // Address3TextBox
            // 
            this.Address3TextBox.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Address3TextBox.Location = new System.Drawing.Point(461, 71);
            this.Address3TextBox.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.Address3TextBox.Multiline = true;
            this.Address3TextBox.Name = "Address3TextBox";
            this.Address3TextBox.Size = new System.Drawing.Size(369, 21);
            this.Address3TextBox.TabIndex = 142;
            // 
            // PostcodeTextBox
            // 
            this.PostcodeTextBox.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PostcodeTextBox.Location = new System.Drawing.Point(461, 109);
            this.PostcodeTextBox.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.PostcodeTextBox.Multiline = true;
            this.PostcodeTextBox.Name = "PostcodeTextBox";
            this.PostcodeTextBox.Size = new System.Drawing.Size(128, 21);
            this.PostcodeTextBox.TabIndex = 143;
            // 
            // CheckInBtn
            // 
            this.CheckInBtn.Location = new System.Drawing.Point(7, 173);
            this.CheckInBtn.Name = "CheckInBtn";
            this.CheckInBtn.Size = new System.Drawing.Size(87, 38);
            this.CheckInBtn.TabIndex = 144;
            this.CheckInBtn.Text = "Add Customer";
            this.CheckInBtn.UseVisualStyleBackColor = true;
            this.CheckInBtn.Click += new System.EventHandler(this.CheckInBtn_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Calibri", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(4, 147);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 17);
            this.label3.TabIndex = 145;
            this.label3.Text = "Phone Number";
            // 
            // PhoneNumberTextBox
            // 
            this.PhoneNumberTextBox.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PhoneNumberTextBox.Location = new System.Drawing.Point(111, 146);
            this.PhoneNumberTextBox.Margin = new System.Windows.Forms.Padding(2, 3, 2, 3);
            this.PhoneNumberTextBox.Multiline = true;
            this.PhoneNumberTextBox.Name = "PhoneNumberTextBox";
            this.PhoneNumberTextBox.Size = new System.Drawing.Size(220, 21);
            this.PhoneNumberTextBox.TabIndex = 146;
            // 
            // NewCustomerPanel
            // 
            this.NewCustomerPanel.AutoScroll = true;
            this.NewCustomerPanel.Controls.Add(this.PhoneNumberTextBox);
            this.NewCustomerPanel.Controls.Add(this.label3);
            this.NewCustomerPanel.Controls.Add(this.CheckInBtn);
            this.NewCustomerPanel.Controls.Add(this.PostcodeTextBox);
            this.NewCustomerPanel.Controls.Add(this.Address3TextBox);
            this.NewCustomerPanel.Controls.Add(this.Address2TextBox);
            this.NewCustomerPanel.Controls.Add(this.SurnameTextBox);
            this.NewCustomerPanel.Controls.Add(this.Address1TextBox);
            this.NewCustomerPanel.Controls.Add(this.ForenameTextBox);
            this.NewCustomerPanel.Controls.Add(this.GenderComboBox);
            this.NewCustomerPanel.Controls.Add(this.label9);
            this.NewCustomerPanel.Controls.Add(this.DOBDateTimePicker);
            this.NewCustomerPanel.Controls.Add(this.label7);
            this.NewCustomerPanel.Controls.Add(this.label8);
            this.NewCustomerPanel.Controls.Add(this.label5);
            this.NewCustomerPanel.Controls.Add(this.label6);
            this.NewCustomerPanel.Controls.Add(this.label4);
            this.NewCustomerPanel.Controls.Add(this.label2);
            this.NewCustomerPanel.Controls.Add(this.label1);
            this.NewCustomerPanel.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.NewCustomerPanel.Location = new System.Drawing.Point(0, 59);
            this.NewCustomerPanel.Margin = new System.Windows.Forms.Padding(1);
            this.NewCustomerPanel.Name = "NewCustomerPanel";
            this.NewCustomerPanel.Padding = new System.Windows.Forms.Padding(2);
            this.NewCustomerPanel.Size = new System.Drawing.Size(872, 330);
            this.NewCustomerPanel.TabIndex = 110;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label22);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(872, 55);
            this.panel1.TabIndex = 111;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.Transparent;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F);
            this.label22.Location = new System.Drawing.Point(13, 9);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(161, 25);
            this.label22.TabIndex = 109;
            this.label22.Text = "Customer Details";
            // 
            // CustomerDetails
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScrollMargin = new System.Drawing.Size(30, 30);
            this.ClientSize = new System.Drawing.Size(872, 389);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.NewCustomerPanel);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "CustomerDetails";
            this.Text = "Welcome to Roadstar Hotel!";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.NewCustomerPanel.ResumeLayout(false);
            this.NewCustomerPanel.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DateTimePicker DOBDateTimePicker;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox GenderComboBox;
        private System.Windows.Forms.TextBox ForenameTextBox;
        private System.Windows.Forms.TextBox Address1TextBox;
        private System.Windows.Forms.TextBox SurnameTextBox;
        private System.Windows.Forms.TextBox Address2TextBox;
        private System.Windows.Forms.TextBox Address3TextBox;
        private System.Windows.Forms.TextBox PostcodeTextBox;
        private System.Windows.Forms.Button CheckInBtn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox PhoneNumberTextBox;
        private System.Windows.Forms.Panel NewCustomerPanel;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label22;
    }
}

