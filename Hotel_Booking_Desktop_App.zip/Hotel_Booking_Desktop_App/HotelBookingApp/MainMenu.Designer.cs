﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelBookingApp
{
    partial class MainMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainMenu));
            this.panel1 = new System.Windows.Forms.Panel();
            this.newCustomerButton = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.ReportsBtn = new System.Windows.Forms.Button();
            this.ManageRoomsButton = new System.Windows.Forms.Button();
            this.ManageBookingBtn = new System.Windows.Forms.Button();
            this.NewBookingBtn = new System.Windows.Forms.Button();
            this.panelLogo = new System.Windows.Forms.Panel();
            this.panelSubMenu = new System.Windows.Forms.Panel();
            this.DetailsPanel = new System.Windows.Forms.Panel();
            this.panelDesktopPane = new System.Windows.Forms.Panel();
            this.panel1.SuspendLayout();
            this.panelSubMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.button7);
            this.panel1.Controls.Add(this.button6);
            this.panel1.Controls.Add(this.button5);
            this.panel1.Controls.Add(this.ReportsBtn);
            this.panel1.Controls.Add(this.ManageRoomsButton);
            this.panel1.Controls.Add(this.ManageBookingBtn);
            this.panel1.Controls.Add(this.NewBookingBtn);
            this.panel1.Controls.Add(this.newCustomerButton);
            this.panel1.Controls.Add(this.panelLogo);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(253, 697);
            this.panel1.TabIndex = 0;
            // 
            // newCustomerButton
            // 
            this.newCustomerButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.newCustomerButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.newCustomerButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.newCustomerButton.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.newCustomerButton.Location = new System.Drawing.Point(0, 130);
            this.newCustomerButton.Name = "newCustomerButton";
            this.newCustomerButton.Size = new System.Drawing.Size(253, 69);
            this.newCustomerButton.TabIndex = 1;
            this.newCustomerButton.Text = "New Customer";
            this.newCustomerButton.UseVisualStyleBackColor = true;
            this.newCustomerButton.Click += new System.EventHandler(this.newCustomerButton_Click);
            // 
            // button7
            // 
            this.button7.Dock = System.Windows.Forms.DockStyle.Top;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button7.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.button7.Location = new System.Drawing.Point(0, 613);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(253, 69);
            this.button7.TabIndex = 8;
            this.button7.Text = "Other Function 3";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Dock = System.Windows.Forms.DockStyle.Top;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button6.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.button6.Location = new System.Drawing.Point(0, 544);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(253, 69);
            this.button6.TabIndex = 7;
            this.button6.Text = "Other Function 2";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Dock = System.Windows.Forms.DockStyle.Top;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.button5.Location = new System.Drawing.Point(0, 475);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(253, 69);
            this.button5.TabIndex = 6;
            this.button5.Text = "Other Function";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // ReportsBtn
            // 
            this.ReportsBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.ReportsBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ReportsBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ReportsBtn.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.ReportsBtn.Location = new System.Drawing.Point(0, 406);
            this.ReportsBtn.Name = "ReportsBtn";
            this.ReportsBtn.Size = new System.Drawing.Size(253, 69);
            this.ReportsBtn.TabIndex = 5;
            this.ReportsBtn.Text = "Reports";
            this.ReportsBtn.UseVisualStyleBackColor = true;
            this.ReportsBtn.Click += new System.EventHandler(this.Reports_button_Click);
            // 
            // ManageRoomsButton
            // 
            this.ManageRoomsButton.Dock = System.Windows.Forms.DockStyle.Top;
            this.ManageRoomsButton.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ManageRoomsButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ManageRoomsButton.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.ManageRoomsButton.Location = new System.Drawing.Point(0, 337);
            this.ManageRoomsButton.Name = "ManageRoomsButton";
            this.ManageRoomsButton.Size = new System.Drawing.Size(253, 69);
            this.ManageRoomsButton.TabIndex = 4;
            this.ManageRoomsButton.Text = "Manage Rooms";
            this.ManageRoomsButton.UseVisualStyleBackColor = true;
            this.ManageRoomsButton.Click += new System.EventHandler(this.button3_Click);
            // 
            // ManageBookingBtn
            // 
            this.ManageBookingBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.ManageBookingBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ManageBookingBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ManageBookingBtn.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.ManageBookingBtn.Location = new System.Drawing.Point(0, 268);
            this.ManageBookingBtn.Name = "ManageBookingBtn";
            this.ManageBookingBtn.Size = new System.Drawing.Size(253, 69);
            this.ManageBookingBtn.TabIndex = 3;
            this.ManageBookingBtn.Text = "Manage Bookings";
            this.ManageBookingBtn.UseVisualStyleBackColor = true;
            this.ManageBookingBtn.Click += new System.EventHandler(this.button2_Click);
            // 
            // NewBookingBtn
            // 
            this.NewBookingBtn.Dock = System.Windows.Forms.DockStyle.Top;
            this.NewBookingBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.NewBookingBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NewBookingBtn.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.NewBookingBtn.Location = new System.Drawing.Point(0, 199);
            this.NewBookingBtn.Name = "NewBookingBtn";
            this.NewBookingBtn.Size = new System.Drawing.Size(253, 69);
            this.NewBookingBtn.TabIndex = 2;
            this.NewBookingBtn.Text = "New booking";
            this.NewBookingBtn.UseVisualStyleBackColor = true;
            this.NewBookingBtn.Click += new System.EventHandler(this.NewBooking_Click);
            // 
            // panelLogo
            // 
            this.panelLogo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panelLogo.BackgroundImage")));
            this.panelLogo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panelLogo.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelLogo.Location = new System.Drawing.Point(0, 0);
            this.panelLogo.Name = "panelLogo";
            this.panelLogo.Size = new System.Drawing.Size(253, 130);
            this.panelLogo.TabIndex = 0;
            this.panelLogo.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // panelSubMenu
            // 
            this.panelSubMenu.Controls.Add(this.DetailsPanel);
            this.panelSubMenu.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelSubMenu.Location = new System.Drawing.Point(253, 0);
            this.panelSubMenu.Name = "panelSubMenu";
            this.panelSubMenu.Size = new System.Drawing.Size(922, 130);
            this.panelSubMenu.TabIndex = 1;
            // 
            // DetailsPanel
            // 
            this.DetailsPanel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(99)))), ((int)(((byte)(130)))));
            this.DetailsPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this.DetailsPanel.Location = new System.Drawing.Point(0, 0);
            this.DetailsPanel.Name = "DetailsPanel";
            this.DetailsPanel.Size = new System.Drawing.Size(922, 130);
            this.DetailsPanel.TabIndex = 0;
            // 
            // panelDesktopPane
            // 
            this.panelDesktopPane.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.panelDesktopPane.Location = new System.Drawing.Point(253, 130);
            this.panelDesktopPane.Name = "panelDesktopPane";
            this.panelDesktopPane.Size = new System.Drawing.Size(922, 567);
            this.panelDesktopPane.TabIndex = 2;
            this.panelDesktopPane.Paint += new System.Windows.Forms.PaintEventHandler(this.panelDesktopPane_Paint);
            // 
            // MainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(99)))), ((int)(((byte)(130)))));
            this.ClientSize = new System.Drawing.Size(1175, 697);
            this.Controls.Add(this.panelDesktopPane);
            this.Controls.Add(this.panelSubMenu);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "MainMenu";
            this.Text = "Welcome to Roadstar Hotel!";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.panel1.ResumeLayout(false);
            this.panelSubMenu.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
        public System.Windows.Forms.Button ReportsBtn;
        private System.Windows.Forms.Button ManageRoomsButton;
        private System.Windows.Forms.Button ManageBookingBtn;
        private System.Windows.Forms.Button NewBookingBtn;
        private System.Windows.Forms.Panel panelLogo;
        private System.Windows.Forms.Panel panelSubMenu;
        private System.Windows.Forms.Panel panelDesktopPane;
        private Form activeForm;
        private Form activeDetailsForm;

        public void OpenChildform(Form childForm, object btnSender)
        {
            
            activeForm = childForm;
            childForm.TopLevel = false;
            childForm.FormBorderStyle = FormBorderStyle.None;
            childForm.Dock = DockStyle.Fill;
            this.panelDesktopPane.Controls.Add(childForm);
            this.panelDesktopPane.Tag = childForm;
            childForm.BringToFront();
            childForm.Show();
        }

        public void OpenDetailsform(Form DetailsForm, object btnSender)
        {
            

            activeDetailsForm = DetailsForm;
            DetailsForm.TopLevel = false;
            DetailsForm.FormBorderStyle = FormBorderStyle.None;
            DetailsForm.Dock = DockStyle.Fill;
            this.DetailsPanel.Controls.Add(DetailsForm);
            this.DetailsPanel.Tag = DetailsForm;
            DetailsForm.BringToFront();
            DetailsForm.Show();
        }

        private Panel DetailsPanel;
        private Button newCustomerButton;
    }




}


